<?php

class CalypsoPaymentWidgetSettings {

    public string $full = 'full';
    public string $keyFieldId = 'key';
    public string $urlFieldId = 'url';
    public string $currencyFieldId = 'currency';
    public string $ethWalletFieldId = 'ethWallet';
    public string $btcWalletFieldId = 'btcWallet';
    public string $trxWalletFieldId = 'trxWallet';
    public string $trxUSDTWalletFieldId = 'trxUSDTWallet';

	public string $optionName = 'calypso_payment_widget_settings_options';
	private string $optionPage = 'calypso-payment-widget-settings';
	private string $optionGroup = 'calypso_payment_widget_settings_group';
	private string $sectionId = 'calypso_payment_widget_settings_section';

	function create( $pluginName ) {
		add_action( 'admin_menu', [ $this, 'addAdminMenu' ] );
		add_filter( 'plugin_action_links_' . $pluginName, [ $this, 'addPluginSettingLink' ] );
		add_action( 'admin_init', [ $this, 'settingsInit' ] );
	}

	function addAdminMenu() {
		add_menu_page(
			esc_html__( 'Calypso Payment Widget Settings', 'calypso-payment-widget' ),
			esc_html__( 'Calypso Payment Widget Settings', 'calypso-payment-widget' ),
			'manage_options',
			$this->optionPage,
			[ $this, 'getAdminMenuContent' ],
			'dashicons-money-alt'
		);
	}

	function addPluginSettingLink( $link ) {
		$page_link = '<a href="admin.php?page=' . $this->optionPage . '">Settings</a>';
		$link[]    = $page_link;

		return $link;
	}

	function getAdminMenuContent() {
		?>
        <div class="wrap">
            <h1>Calypso Payment Widget Settings</h1>
            <div class="content">
                <form method="post" action="options.php">
					<?php
					settings_fields( $this->optionGroup );
					do_settings_sections( $this->optionPage );
					submit_button();
					?>
                </form>
            </div>
        </div>
		<?php
	}

	function settingsInit() {
		register_setting( $this->optionGroup, $this->optionName );
		add_settings_section(
			$this->sectionId,
			'',
			'',
			$this->optionPage
		);
		$this->addTextField($this->urlFieldId, 'Url');
		$this->addTextField($this->keyFieldId, 'Reusable Key');
		$this->addTextField($this->currencyFieldId, 'Currency');
		$this->addTextField($this->ethWalletFieldId, 'Ethereum Wallet');
		$this->addTextField($this->btcWalletFieldId, 'Bitcoin Wallet');
		$this->addTextField($this->trxWalletFieldId, 'Tron Wallet');
		$this->addTextField($this->trxUSDTWalletFieldId, 'USDT Tron Wallet');
		$this->addCheckBoxField($this->full, 'Full size');
	}

	function addTextField( $id, $title ) {
		add_settings_field(
			$id,
			$title,
			function () use ($id) {
				?>
                <input name="<?= $this->optionName ?>[<?= $id ?>]" value="<?= $this->getOptionValue( $id ) ?>">
				<?php
            },
			$this->optionPage,
			$this->sectionId
		);
	}

	function addCheckBoxField( $id, $title ) {
		add_settings_field(
			$id,
			$title,
			function () use ($id) {
				?>
                <input type="checkbox" name="<?= $this->optionName ?>[<?= $id ?>]" value="1" <?= checked(1, $this->getOptionValue( $id ), false ) ?>>
				<?php
			},
			$this->optionPage,
			$this->sectionId
		);
	}

	function getOptionValue( $name ) {
		return get_option( $this->optionName )[ $name ] ?? '';
	}
}
