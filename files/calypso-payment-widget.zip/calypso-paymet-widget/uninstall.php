<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	die;
}

global $wpdb;
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name = 'calypso_payment_widget_settings_options'");