=== Calypso Payment Widget ===
Contributors: yandexpay
Tags: calypso, payment widget
Requires at least: 6.0
Tested up to: 6.0
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Calypso Payment Widget

== Description ==

Заполните соответствующие поля в настройках плагина:

Url - адрес страницы виджета на сервере Calypso
Reusable Key - ключ
Currency - валюта платежа
Ethereum Wallet - адрес кошелька Ethereum
Bitcoin Wallet - адрес кошелька Bitcoin
Tron Wallet - адрес кошелька Tron
USDT Tron Wallet - адрес кошелька Tron USDT
Full size - размер виджета


Добавьте shortcode в редакторе на странице:

[calypso-payment-widget-button description='' amount='']

description - описание товара
amount - сумма в валюте указанной в настройках плагина

теги description и amount не должны быть пустыми