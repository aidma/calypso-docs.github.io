<?php

class CalypsoPaymentWidgetShortCode {

	private CalypsoPaymentWidgetSettings $settings;
	private $options;

	public function __construct(CalypsoPaymentWidgetSettings $settings) {
		$this->settings = $settings;
	}

	function init() {
		$this->options = get_option( $this->settings->optionName );
		add_shortcode( 'calypso-payment-widget-button', [ $this, 'paymentButton' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_front_assets' ] );
	}

	function paymentButton( $attrs, $content, $tag ): string {
		if ( ! $this->isValidButtonSettings( $attrs ) ) {
			return '<div class="calypso-payment-widget-settings-validate-error">' .
			       'Calypso payment widget settings error' .
			       '</div>';
		}

		$description = $attrs['description'];
		$amount      = $attrs['amount'];

		$html = '<form method="get" target="calypso-payment-widget-frame" action="' . $this->options[ $this->settings->urlFieldId ] . '" name="calypso-payment-widget-form" hidden>'
		        . '<input name="key" value="' . $this->options[ $this->settings->keyFieldId ] . '">'
		        . '<input name="full" value="' . ( isset( $this->options[ $this->settings->full ] ) ? 'true' : 'false' ) . '">'
		        . '<input name="currency" value="' . $this->options[ $this->settings->currencyFieldId ] . '">'
		        . '<input name="amount" value="' . $amount . '">'
		        . '<input name="description" value="' . $description . '">';
		if ( ! empty( $this->options[ $this->settings->ethWalletFieldId ] ) ) {
			$html .= '<input name="eth_wallet" value="' . $this->options[ $this->settings->ethWalletFieldId ] . '">';
		}
		if ( ! empty( $this->options[ $this->settings->btcWalletFieldId ] ) ) {
			$html .= '<input name="btc_wallet" value="' . $this->options[ $this->settings->btcWalletFieldId ] . '">';
		}
		if ( ! empty( $this->options[ $this->settings->trxWalletFieldId ] ) ) {
			$html .= '<input name="trx_wallet" value="' . $this->options[ $this->settings->trxWalletFieldId ] . '">';
		}
		if ( ! empty( $this->options[ $this->settings->trxUSDTWalletFieldId ] ) ) {
			$html .= '<input name="usdt_trx_wallet" value="' . $this->options[ $this->settings->trxUSDTWalletFieldId ] . '">';
		}
		$html .= '</form>'
		         . '<div class="calypso-payment-widget-submit" onclick="calypsoFormSubmit()">Pay</div>';

		return $html;

	}

	function isValidButtonSettings( $attrs ): bool {
		$isValid = true;
		if (
			! is_array( $this->options ) ||
			! isset( $this->options[ $this->settings->urlFieldId ] ) ||
			! isset( $this->options[ $this->settings->keyFieldId ] ) ||
			! isset( $this->options[ $this->settings->currencyFieldId ] ) ||
			! isset( $attrs['description'] ) ||
			! isset( $attrs['amount'] )
		) {
			$isValid = false;
		}
		if ( ! isset( $this->options[ $this->settings->ethWalletFieldId ] ) &&
		     ! isset( $this->options[ $this->settings->btcWalletFieldId ] ) &&
		     ! isset( $this->options[ $this->settings->trxWalletFieldId ] ) &&
		     ! isset( $this->options[ $this->settings->trxUSDTWalletFieldId ] )
		) {
			$isValid = false;
		}
		if ( empty( $this->options[ $this->settings->ethWalletFieldId ] ) &&
		     empty( $this->options[ $this->settings->btcWalletFieldId ] ) &&
		     empty( $this->options[ $this->settings->trxWalletFieldId ] ) &&
		     empty( $this->options[ $this->settings->trxUSDTWalletFieldId ] )
		) {
			$isValid = false;
		}
		if ( ! is_numeric( $attrs['amount'] ) ) {
			$isValid = false;
		}

		return $isValid;
	}

	function enqueue_front_assets() {
		wp_enqueue_style( 'calypso-payment-widget-style', plugins_url( '/assets/front/style.css', dirname(__FILE__, 1) ) );
		wp_enqueue_script( 'calypso-payment-widget-scrypt', plugins_url( '/assets/front/scrypt.js', dirname(__FILE__, 1)) );
	}
}