function addIframe() {
  const div = document.createElement('div');

  div.id = 'calypso-payment-widget-div'
  div.innerHTML = '<div class="close">' +
    '<div class="vertical"></div>' +
    '<div class="horisontal"></div>' +
    '</div>' +
    '<iframe name="calypso-payment-widget-frame"></iframe>'

  document.body.appendChild(div);
}

function calypsoFormSubmit() {
  const form = document.getElementsByName('calypso-payment-widget-form')[0].submit();
  document.getElementById('calypso-payment-widget-div').style.display = 'flex'
}

function closeIframe() {
  const div = document.getElementById('calypso-payment-widget-div');
  const close = div.getElementsByClassName('close')[0];
  close.onclick = function () {
      div.style.display = 'none'
  }

}

window.onload = function () {
  addIframe()
  closeIframe()
}