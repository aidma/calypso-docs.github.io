<?php
/**
 * Calypso Payment Widget
 *
 * Plugin Name: Calypso Payment Widget
 * Plugin URI:
 * Description: Enables Calypso Payment Widget
 * Version:     1.0
 * Author:      Calypso
 * Author URI:
 * License:     GPLv2 or later
 * License URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: calypso-payment-widget
 * Domain Path: /calypso-payment-widget
 * Requires at least: 6.0
 * Tested up to: 6.0
 * Requires PHP: 7.4
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the GNU
 * General Public License version 2, as published by the Free Software Foundation. You may NOT assume
 * that you can use any other version of the GPL.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'CALYPSO_PAYMENT_WIDGET_PLUGIN_DIR' ) ) {
	define( 'CALYPSO_PAYMENT_WIDGET_PLUGIN_DIR', dirname( __FILE__ ) );
}

require_once CALYPSO_PAYMENT_WIDGET_PLUGIN_DIR . '/admin/settings.php';
require_once CALYPSO_PAYMENT_WIDGET_PLUGIN_DIR . '/front/short-code.php';

$settings = new CalypsoPaymentWidgetSettings();
$settings->create( plugin_basename( __FILE__ ) );

$shortCode = new CalypsoPaymentWidgetShortCode($settings);
$shortCode->init();